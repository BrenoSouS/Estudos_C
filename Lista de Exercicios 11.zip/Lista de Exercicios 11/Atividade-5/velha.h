#ifndef VELHA_H_INCLUDED
#define VELHA_H_INCLUDED

#include <stdbool.h>
#include <stdio.h>
#define TAM 3

//inicializa a matriz com todos os elementos iguais a 0
void InicializarMatriz(int Matriz[TAM][TAM]);

//Recebe a jogada do usu�rio
void ReceberJogada(int Matriz[TAM][TAM], int QualJogador);

//Retorna se algu�m ganhou.
//A fun��o retornar�: 0 ningu�m venceu;
//                    1 jogador 1 venceu;
//                    2 jogador 2 venceu;
//                   -1 deu velha.
int VerificarVencedor(int Matriz[TAM][TAM]);

//Mostrar tabuleiro na tela
void MostraMatriz(int Matriz[TAM][TAM]);

void Cabecalho();

#endif // VELHA_H_INCLUDED
