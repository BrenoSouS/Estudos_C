#include <stdio.h>
#include <stdlib.h>
#include "velha.h"

int main()
{
    int Matriz[TAM][TAM];
    int Resultado;
    int QualJogador = 1;

    InicializarMatriz(Matriz);
    do
    {
        system("cls");
        Cabecalho();
        MostraMatriz(Matriz);
        ReceberJogada(Matriz,QualJogador);
        Resultado = VerificarVencedor(Matriz);
        if (QualJogador == 1)
            QualJogador = 2;
        else
            QualJogador = 1;
    }while(Resultado == 0);
    system("cls");
    Cabecalho();
    MostraMatriz(Matriz);

    printf("\n**************** FIM DE JOGO *****************\n");
    switch(Resultado)
    {
        case 1: printf("\nJOGADOR 1 VENCEDOR!!!\n");
                break;
        case 2: printf("\nJOGADOR 2 VENCEDOR!!!\n");
                break;
        case -1: printf("\nDEU VELHA!!!\n");
                break;
    }
    printf("\n**************** FIM DE JOGO *****************\n");
    return 0;
}
