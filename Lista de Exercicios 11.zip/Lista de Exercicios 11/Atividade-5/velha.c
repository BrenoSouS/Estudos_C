#include "velha.h"

void InicializarMatriz(int Matriz[TAM][TAM])
{
    for(int i = 0; i < TAM; i++)
        for(int j = 0; j < TAM; j++)
            Matriz[i][j] = 0;
}

void ReceberJogada(int Matriz[TAM][TAM], int QualJogador)
{
    int linha = 0, coluna = 0;
    bool erro = false;
    printf("Jogador %d, informe sua jogada:\n",QualJogador);
    do
    {
        erro = false;
        printf("Informe a Linha (1, 2 ou 3): ");
        scanf("%d",&linha);
        printf("Informe a Coluna (1, 2 ou 3): ");
        scanf("%d",&coluna);
        if ((linha < 1) || (linha > TAM) ||
            (coluna < 1) || (coluna > TAM))
        {
                printf("**ERRO**. INTERVALO INCORRETO!\n");
                erro = true;
        }
        else
        {
             if (Matriz[linha-1][coluna-1] != 0)
             {
                printf("**ERRO**. POSICAO JA ESTA OCUPADA!\n");
                erro = true;
             }
        }

    }while(erro);

    Matriz[linha-1][coluna-1] = QualJogador;
}

int VerificarVencedor(int Matriz[TAM][TAM])
{
    int qtdeJog1 = 0;
    int qtdeJog2 = 0;

    //verificar se deu velha
    bool temZero = false;
    for(int i = 0; i < TAM; i++)
    {
        for(int j = 0; j < TAM; j++)
        {
            if (Matriz[i][j] == 0)
                temZero = true;
        }
    }
    if (!temZero)
    {
        return -1; //deu velha
    }

    //verificar linhas
    for(int i = 0; i < TAM; i++) //para cada linha
    {
        qtdeJog1 = 0;
        qtdeJog2 = 0;
        for(int j = 0; j < TAM; j++)
        {
            if(Matriz[i][j] == 1)
                qtdeJog1++;
            if(Matriz[i][j] == 2)
                qtdeJog2++;
        }
        if (qtdeJog1 == TAM)
            return 1; //jogador 1 venceu
        if (qtdeJog2 == TAM)
            return 2; //jogador 2 venceu
    }

    //verificar diagonal principal
    qtdeJog1 = 0;
    qtdeJog2 = 0;
    for(int i = 0; i < TAM; i++)
    {
        if(Matriz[i][i] == 1)
            qtdeJog1++;
        if(Matriz[i][i] == 2)
            qtdeJog2++;
    }
    if (qtdeJog1 == TAM)
        return 1; //jogador 1 venceu
    if (qtdeJog2 == TAM)
        return 2; //jogador 2 venceu

    //verificar diagonal secundaria
    qtdeJog1 = 0;
    qtdeJog2 = 0;
    for(int i = 0, j = TAM-1; i < TAM; i++, j--)
    {
        if(Matriz[i][j] == 1)
            qtdeJog1++;
        if(Matriz[i][j] == 2)
            qtdeJog2++;
    }
    if (qtdeJog1 == TAM)
        return 1; //jogador 1 venceu
    if (qtdeJog2 == TAM)
        return 2; //jogador 2 venceu

    //verificar colunas
    for(int j = 0; j < TAM; j++) //para cada coluna
    {
        qtdeJog1 = 0;
        qtdeJog2 = 0;
        for(int i = 0; i < TAM; i++)
        {
            if(Matriz[i][j] == 1)
                qtdeJog1++;
            if(Matriz[i][j] == 2)
                qtdeJog2++;
        }
        if (qtdeJog1 == TAM)
            return 1; //jogador 1 venceu
        if (qtdeJog2 == TAM)
            return 2; //jogador 2 venceu
    }

    return 0;
}

void MostraMatriz(int Matriz[TAM][TAM])
{
    printf("+---+---+---+\n");
    for(int i = 0; i < TAM; i++)
    {
        printf("|");
        for(int j = 0; j < TAM; j++)
        {
            if (Matriz[i][j] == 1)
                printf(" X |");
            if (Matriz[i][j] == 2)
                printf(" 0 |");
            if (Matriz[i][j] == 0)
                printf("   |");
        }
        printf("\n");
    }
    printf("+---+---+---+\n");
}

void Cabecalho()
{
    printf("+======================================+\n");
    printf("|   IFTM - ENGENHARIA DE COMPUTACAO    |\n");
    printf("+======================================+\n");
    printf("| Disciplina: Algoritmos e Programacao |\n");
    printf("| Professor : Ernani Viriato de Melo   |\n");
    printf("+======================================+\n");
    printf("|  JOGO FRIQUE FRAQUE (JOGO DA VELHA)  |\n");
    printf("+======================================+\n");
}

