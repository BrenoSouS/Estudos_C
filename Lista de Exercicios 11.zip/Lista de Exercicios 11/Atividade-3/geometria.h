
#ifndef GEOMETRIA_H

#define GEOMETRIA_H

#include<stdio.h>
#include<stdlib.h>

 int areaRetangulo(int altura, int largura);

 int PerimetroRetangulo(int altura, int largura);

 float areaTriangulo(int altura, int base);

 #endif