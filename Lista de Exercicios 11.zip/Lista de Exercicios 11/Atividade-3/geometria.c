#include"geometria.h"

int areaRetangulo(int altura, int largura){

int area = altura * largura;
return area;

}

int PerimetroRetangulo(int altura, int largura){

int perimetro = altura*2 + largura*2;

return perimetro;

}

float areaTriangulo(int altura, int base){

    float area = (base*altura)/2;

    return base;


}