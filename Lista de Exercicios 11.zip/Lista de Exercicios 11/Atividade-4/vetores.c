#include <iostream>
#include "vetores.h"

using namespace std;

void InicializarVetor(int Vetor[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        Vetor[i] = 0;
    }
}

void ReceberVetor(int Vetor[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        cout << "Digite o valor da posição " << i << ": ";
        cin >> Vetor[i];
    }
}

int MaiorNroVetor(int Vetor[], int tamanho) {
    int maior = Vetor[0];
    for (int i = 1; i < tamanho; i++) {
        if (Vetor[i] > maior)
            maior = Vetor[i];
    }
    return maior;
}

int PosicaoNroVetor(int Vetor[], int tamanho, int Nro) {
    for (int i = 0; i < tamanho; i++) {
        if (Vetor[i] == Nro)
            return i;
    }
    return -1; // Não encontrado
}

int FrequenciaNroVetor(int Vetor[], int tamanho, int Nro) {
    int cont = 0;
    for (int i = 0; i < tamanho; i++) {
        if (Vetor[i] == Nro)
            cont++;
    }
    return cont;
}
