#include <stdio.h>
#include "vetores.h"

int main() {
    int tamanho = 5;
    int numeros[5];

    InicializarVetor(numeros, tamanho);
    ReceberVetor(numeros, tamanho);

    int maior = MaiorNroVetor(numeros, tamanho);
    printf("Maior número do vetor: %d\n", maior);

    int busca;
    printf("Digite um número para buscar sua posição: ");
    scanf("%d", &busca);

    int pos = PosicaoNroVetor(numeros, tamanho, busca);
    if (pos != -1) {
        printf("Número encontrado na posição: %d\n", pos);
    } else {
        printf("Número não encontrado no vetor.\n");
    }

    int freq = FrequenciaNroVetor(numeros, tamanho, busca);
    printf("Frequência do número %d: %d\n", busca, freq);

    return 0;
}
