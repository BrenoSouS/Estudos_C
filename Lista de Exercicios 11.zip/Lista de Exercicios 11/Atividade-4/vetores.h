#ifndef VETORES_H
#define VETORES_H

void InicializarVetor(int Vetor[], int tamanho);
void ReceberVetor(int Vetor[], int tamanho);
int MaiorNroVetor(int Vetor[], int tamanho);
int PosicaoNroVetor(int Vetor[], int tamanho, int Nro);
int FrequenciaNroVetor(int Vetor[], int tamanho, int Nro);

#endif